
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author sstan
 */
public class TicTacToe extends javax.swing.JFrame {

    /**
     * Creates new form TicTacToe
     */
    private String NEWGAME = "X";
    private int Xcount = 0;
    private int Ocount = 0;
    boolean check; 
    
    public TicTacToe() {
        initComponents();
    }
    
    private void Player()
    {
        if(NEWGAME.equalsIgnoreCase("X")) {
            NEWGAME = "O";
        } else {
            NEWGAME = "X"; 
        }
    } // END OF player
    
    private void GameWon() {
        String b1 = Button1.getText(); 
        String b2 = Button2.getText(); 
        String b3 = Button3.getText(); 
        String b4 = Button4.getText();
        String b5 = Button5.getText(); 
        String b6 = Button6.getText(); 
        String b7 = Button7.getText(); 
        String b8 = Button8.getText();
        String b9 = Button9.getText();
        
        
        if (b1 == ("X") && b2 == ("X") && b3 == ("X")) {
          JOptionPane.showMessageDialog(this, "Player X Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button1.setBackground(Color.GREEN);
            Button2.setBackground(Color.GREEN);
            Button3.setBackground(Color.GREEN);
            Xcount++;  
        } // end of if (123)
        
        if (b4 == ("X") && b5 == ("X") && b6 == ("X")) {
          JOptionPane.showMessageDialog(this, "Player X Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button4.setBackground(Color.GREEN);
            Button5.setBackground(Color.GREEN);
            Button6.setBackground(Color.GREEN);
            Xcount++;  
        } // end of if (456)
        
        if (b7 == ("X") && b8 == ("X") && b9 == ("X")) {
          JOptionPane.showMessageDialog(this, "Player X Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button7.setBackground(Color.GREEN);
            Button8.setBackground(Color.GREEN);
            Button9.setBackground(Color.GREEN);
            Xcount++;  
        } // end of if (789)
        
        if (b1 == ("O") && b2 == ("O") && b3 == ("O")) {
          JOptionPane.showMessageDialog(this, "Player O Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button1.setBackground(Color.GREEN);
            Button2.setBackground(Color.GREEN);
            Button3.setBackground(Color.GREEN);
            Xcount++; 
        } // end of if (123)
        
        if (b4 == ("O") && b5 == ("O") && b6 == ("O")) {
          JOptionPane.showMessageDialog(this, "Player O Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button4.setBackground(Color.GREEN);
            Button5.setBackground(Color.GREEN);
            Button6.setBackground(Color.GREEN);
            Ocount++; 
        } // end of if (456)
        
        if (b7 == ("O") && b8 == ("O") && b9 == ("O")) {
          JOptionPane.showMessageDialog(this, "Player O Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button7.setBackground(Color.GREEN);
            Button8.setBackground(Color.GREEN);
            Button9.setBackground(Color.GREEN);
            Ocount++;  
        } // end of if (789)
  
            if (b1 == ("X") && b4 == ("X") && b7 == ("X")) {
          JOptionPane.showMessageDialog(this, "Player X Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button1.setBackground(Color.GREEN);
            Button4.setBackground(Color.GREEN);
            Button7.setBackground(Color.GREEN);
            Xcount++; 
        } // end of if (147)
        
        if (b2 == ("X") && b5 == ("X") && b8 == ("X")) {
          JOptionPane.showMessageDialog(this, "Player X Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button2.setBackground(Color.GREEN);
            Button5.setBackground(Color.GREEN);
            Button8.setBackground(Color.GREEN);
            Xcount++; 
        } // end of if (258)
        
        if (b3 == ("X") && b6 == ("X") && b9 == ("X")) {
          JOptionPane.showMessageDialog(this, "Player X Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button3.setBackground(Color.GREEN);
            Button6.setBackground(Color.GREEN);
            Button9.setBackground(Color.GREEN);
            Xcount++;
        } // end of if (369)
        
        if (b1 == ("O") && b4 == ("O") && b7 == ("O")) {
          JOptionPane.showMessageDialog(this, "Player O Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button1.setBackground(Color.GREEN);
            Button4.setBackground(Color.GREEN);
            Button7.setBackground(Color.GREEN);
            Xcount++; 
        } // end of if (147)
        
        if (b2 == ("O") && b5 == ("O") && b8 == ("O")) {
          JOptionPane.showMessageDialog(this, "Player O Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button2.setBackground(Color.GREEN);
            Button5.setBackground(Color.GREEN);
            Button8.setBackground(Color.GREEN);
            Ocount++;  
        } // end of if (258)
        
        if (b3 == ("O") && b6 == ("O") && b9 == ("O")) {
          JOptionPane.showMessageDialog(this, "Player O Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button3.setBackground(Color.GREEN);
            Button6.setBackground(Color.GREEN);
            Button9.setBackground(Color.GREEN);
            Ocount++; 
        } // end of if (369)
        
           if (b1 == ("X") && b5 == ("X") && b9== ("X")) {
          JOptionPane.showMessageDialog(this, "Player X Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button1.setBackground(Color.GREEN);
            Button5.setBackground(Color.GREEN);
            Button9.setBackground(Color.GREEN);
            Xcount++;  
        } // end of if (159)
        
        if (b3 == ("X") && b5 == ("X") && b7 == ("X")) {
          JOptionPane.showMessageDialog(this, "Player X Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button3.setBackground(Color.GREEN);
            Button5.setBackground(Color.GREEN);
            Button7.setBackground(Color.GREEN);
            Xcount++; 
        } // end of if (357)
        
        if (b1 == ("O") && b5 == ("O") && b9== ("O")) {
          JOptionPane.showMessageDialog(this, "Player O Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button1.setBackground(Color.GREEN);
            Button5.setBackground(Color.GREEN);
            Button9.setBackground(Color.GREEN);
            Ocount++; 
        } // end of if (159)
        
        if (b3 == ("O") && b5 == ("O") && b7 == ("O")) {
          JOptionPane.showMessageDialog(this, "Player O Won!!", "Tic Tac Toe", 
                  JOptionPane.INFORMATION_MESSAGE);   
          
            Button3.setBackground(Color.GREEN);
            Button5.setBackground(Color.GREEN);
            Button7.setBackground(Color.GREEN);
            Ocount++; 
        } // end of if (357)
        
        
    } // end of gamewon

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        EXIT = new javax.swing.JButton();
        RESET = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        newgame = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        playerO = new javax.swing.JLabel();
        playerX = new javax.swing.JLabel();
        X = new javax.swing.JButton();
        O = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        Button7 = new javax.swing.JButton();
        Button1 = new javax.swing.JButton();
        Button4 = new javax.swing.JButton();
        Button2 = new javax.swing.JButton();
        Button5 = new javax.swing.JButton();
        Button3 = new javax.swing.JButton();
        Button6 = new javax.swing.JButton();
        Button9 = new javax.swing.JButton();
        Button8 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        EXIT.setFont(new java.awt.Font("Source Code Pro Semibold", 0, 36)); // NOI18N
        EXIT.setText("EXIT");
        EXIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EXITActionPerformed(evt);
            }
        });

        RESET.setFont(new java.awt.Font("Source Code Pro Semibold", 0, 36)); // NOI18N
        RESET.setText("RESET");
        RESET.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RESETActionPerformed(evt);
            }
        });

        newgame.setFont(new java.awt.Font("Source Code Pro Semibold", 0, 48)); // NOI18N
        newgame.setText("NEW GAME");
        newgame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newgameActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(newgame, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(newgame, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(RESET, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(EXIT, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(79, 79, 79))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(EXIT, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RESET, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel2.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 620, 310));

        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        playerO.setFont(new java.awt.Font("Source Code Pro Semibold", 0, 36)); // NOI18N
        playerO.setText("PLAYER O:");

        playerX.setFont(new java.awt.Font("Source Code Pro Semibold", 0, 36)); // NOI18N
        playerX.setText("PLAYER X:");

        X.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        X.setText("0");
        X.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                XActionPerformed(evt);
            }
        });

        O.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        O.setText("0");
        O.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(playerX)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                        .addComponent(X, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(playerO)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(O, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(playerX, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(X, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(playerO, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(O, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(110, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 610, 310));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 80, 660, 680));

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button7.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Button7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button7ActionPerformed(evt);
            }
        });
        jPanel3.add(Button7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 200, 170));

        Button1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button1ActionPerformed(evt);
            }
        });
        jPanel3.add(Button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 200, 170));

        Button4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Button4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button4ActionPerformed(evt);
            }
        });
        jPanel3.add(Button4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 200, 170));

        Button2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button2ActionPerformed(evt);
            }
        });
        jPanel3.add(Button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 200, 170));

        Button5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Button5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button5ActionPerformed(evt);
            }
        });
        jPanel3.add(Button5, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 200, 200, 170));

        Button3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button3ActionPerformed(evt);
            }
        });
        jPanel3.add(Button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, 200, 170));

        Button6.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Button6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button6ActionPerformed(evt);
            }
        });
        jPanel3.add(Button6, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 200, 200, 170));

        Button9.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Button9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button9ActionPerformed(evt);
            }
        });
        jPanel3.add(Button9, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 380, 200, 170));

        Button8.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Button8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button8ActionPerformed(evt);
            }
        });
        jPanel3.add(Button8, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 380, 200, 170));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 660, 680));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Source Code Pro Semibold", 0, 36)); // NOI18N
        jLabel8.setText("TIC TAC TOE GAME");
        jLabel8.setOpaque(true);
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, 400, 50));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1400, 800));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Button7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button7ActionPerformed
        // TODO add your handling code here:
        Button7.setText(NEWGAME);
        Button7.setEnabled(false);
        
        if(NEWGAME.equalsIgnoreCase("X")) {
            check = false; 
        } else {
            check = true; 
        } 
        Player();
        GameWon(); 
    }//GEN-LAST:event_Button7ActionPerformed

    private void Button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button1ActionPerformed
        // TODO add your handling code here:
        Button1.setText(NEWGAME);
        Button1.setEnabled(false);
        
        if(NEWGAME.equalsIgnoreCase("X")) {
            check = false; 
        } else {
            check = true; 
        } 
        Player();
        GameWon(); 
    }//GEN-LAST:event_Button1ActionPerformed

    private void Button4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button4ActionPerformed
        // TODO add your handling code here:
        Button4.setText(NEWGAME);
        Button4.setEnabled(false);
        
        if(NEWGAME.equalsIgnoreCase("X")) {
            check = false; 
        } else {
            check = true; 
        } 
        Player();
        GameWon();
    }//GEN-LAST:event_Button4ActionPerformed

    private void Button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button2ActionPerformed
        // TODO add your handling code here:
        Button2.setText(NEWGAME);
        Button2.setEnabled(false);
        
        if(NEWGAME.equalsIgnoreCase("X")) {
            check = false; 
        } else {
            check = true; 
        } 
        Player();
        GameWon();
    }//GEN-LAST:event_Button2ActionPerformed

    private void Button5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button5ActionPerformed
        // TODO add your handling code here:
        Button5.setText(NEWGAME);
        Button5.setEnabled(false);
        
        if(NEWGAME.equalsIgnoreCase("X")) {
            check = false; 
        } else {
            check = true; 
        } 
        Player();
        GameWon();
    }//GEN-LAST:event_Button5ActionPerformed

    private void Button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button3ActionPerformed
        // TODO add your handling code here:
        Button3.setText(NEWGAME);
        Button3.setEnabled(false);
        
        if(NEWGAME.equalsIgnoreCase("X")) {
            check = false; 
        } else {
            check = true; 
        } 
        Player();
        GameWon();
    }//GEN-LAST:event_Button3ActionPerformed

    private void Button6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button6ActionPerformed
        // TODO add your handling code here:
        Button6.setText(NEWGAME);
        Button6.setEnabled(false);
        
        if(NEWGAME.equalsIgnoreCase("X")) {
            check = false; 
        } else {
            check = true;  
        } 
        Player();
        GameWon();
    }//GEN-LAST:event_Button6ActionPerformed

    private void Button9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button9ActionPerformed
        // TODO add your handling code here:
        Button9.setText(NEWGAME);
        Button9.setEnabled(false);
        
        if(NEWGAME.equalsIgnoreCase("X")) {
            check = false; 
        } else {
            check = true; 
        } 
        Player();
        GameWon();
    }//GEN-LAST:event_Button9ActionPerformed

    private void Button8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button8ActionPerformed
        // TODO add your handling code here:
        Button8.setText(NEWGAME);
        Button8.setEnabled(false);
        if(NEWGAME.equalsIgnoreCase("X")) {
            check = false; 
        } else {
            check = true; 
        } 
        Player();
        GameWon();
    }//GEN-LAST:event_Button8ActionPerformed
private JFrame frame;
    private void EXITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EXITActionPerformed
        // TODO add your handling code here:
        frame = new JFrame("Exit");
        if(JOptionPane.showConfirmDialog(frame, "Do you want to exit?", "Tic Tac Toe", 
                JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION)
        {
            System.exit(0);
        }
    }//GEN-LAST:event_EXITActionPerformed

    private void RESETActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RESETActionPerformed
        // TODO add your handling code here:
        Button1.setEnabled(true);
        Button2.setEnabled(true);
        Button3.setEnabled(true);
        Button4.setEnabled(true);
        Button5.setEnabled(true);
        Button6.setEnabled(true);
        Button7.setEnabled(true);
        Button8.setEnabled(true);
        Button9.setEnabled(true);
        
        X.setText("0");
        Xcount = 0;
        O.setText("0"); 
        Ocount = 0;
        
        Button1.setText("");
        Button2.setText("");
        Button3.setText("");
        Button4.setText("");
        Button5.setText("");
        Button6.setText("");
        Button7.setText("");
        Button8.setText("");
        Button9.setText("");
        
        Button1.setBackground(Color.WHITE);
        Button2.setBackground(Color.WHITE);
        Button3.setBackground(Color.WHITE);
        Button4.setBackground(Color.WHITE);
        Button5.setBackground(Color.WHITE);
        Button6.setBackground(Color.WHITE);
        Button7.setBackground(Color.WHITE);
        Button8.setBackground(Color.WHITE);
        Button9.setBackground(Color.WHITE);
    }//GEN-LAST:event_RESETActionPerformed

    private void newgameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newgameActionPerformed
        // TODO add your handling code here:
        Button1.setEnabled(true);
        Button2.setEnabled(true);
        Button3.setEnabled(true);
        Button4.setEnabled(true);
        Button5.setEnabled(true);
        Button6.setEnabled(true);
        Button7.setEnabled(true);
        Button8.setEnabled(true);
        Button9.setEnabled(true);
        
        Button1.setText("");
        Button2.setText("");
        Button3.setText("");
        Button4.setText("");
        Button5.setText("");
        Button6.setText("");
        Button7.setText("");
        Button8.setText("");
        Button9.setText("");
        
        Button1.setBackground(Color.WHITE);
        Button2.setBackground(Color.WHITE);
        Button3.setBackground(Color.WHITE);
        Button4.setBackground(Color.WHITE);
        Button5.setBackground(Color.WHITE);
        Button6.setBackground(Color.WHITE);
        Button7.setBackground(Color.WHITE);
        Button8.setBackground(Color.WHITE);
        Button9.setBackground(Color.WHITE);
        
        X.setText(Integer.toString(Xcount));
        O.setText(Integer.toString(Ocount)); 
        
    }//GEN-LAST:event_newgameActionPerformed

    private void XActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_XActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_XActionPerformed

    private void OActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_OActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TicTacToe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TicTacToe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TicTacToe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TicTacToe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TicTacToe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Button1;
    private javax.swing.JButton Button2;
    private javax.swing.JButton Button3;
    private javax.swing.JButton Button4;
    private javax.swing.JButton Button5;
    private javax.swing.JButton Button6;
    private javax.swing.JButton Button7;
    private javax.swing.JButton Button8;
    private javax.swing.JButton Button9;
    private javax.swing.JButton EXIT;
    private javax.swing.JButton O;
    private javax.swing.JButton RESET;
    private javax.swing.JButton X;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JButton newgame;
    private javax.swing.JLabel playerO;
    private javax.swing.JLabel playerX;
    // End of variables declaration//GEN-END:variables
}
